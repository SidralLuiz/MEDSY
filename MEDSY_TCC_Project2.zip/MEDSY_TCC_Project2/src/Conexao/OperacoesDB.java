package Conexao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import Telas.Cads.TelaCadMed;

public class OperacoesDB {

    public void Select() {
        String sql = "SELECT * FROM usuario";
        try (
                //estabeleça a coneção do banco de dados
                Connection conn = ConexaoDB.getConexao(); //prepara os o comando sql a ser executado
                 PreparedStatement stmt = conn.prepareStatement(sql); //rs recebe a execução da query
                 ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                //processa resultados 
                String nomef = rs.getString("nome");
                String email = rs.getString("email");

                System.out.println("deu boa " + nomef + " o email é: " + email);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public class Medico {

        private String nomeMed;
        private String cpfMed;
        private String emailMed;
        private String nascMed;
        private String telefoneMed;
        private String enderecoMed;
        private String crmMed;
        private String especialidadeMed;
        private String senhaMed;

        public Medico(String nomeMed, String cpfMed, String emailMed,
                String nascMed, String telefoneMed,
                String enderecoMed, String crmMed,
                String especialidadeMed, String senhaMed) {
            this.nomeMed = nomeMed;
            this.cpfMed = cpfMed;
            this.emailMed = emailMed;
            this.nascMed = nascMed;
            this.telefoneMed = telefoneMed;
            this.enderecoMed = enderecoMed;
            this.crmMed = crmMed;
            this.especialidadeMed = especialidadeMed;
            this.senhaMed = senhaMed;
        }

        

        public void INSERTMEDICO(String nomeMed, float CpfMed, String emailMed, String nascMed, String telefoneMed, String enderecoMed, String crmMed, String especialidadeMed, int SenhaMed) {

            String sql = "INSERT INTO medico (nomeM, cpfM emailMed, nasm,telefonem, enderecom, crm, especialidade, senham) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
            try (Connection conn = ConexaoDB.getConexao(); PreparedStatement stmt = conn.prepareStatement(sql); ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    stmt.setString(1, nomeMed);         // nome
                    stmt.setFloat(2, CpfMed);           // cpf
                    stmt.setString(3, emailMed);        // email
                    stmt.setString(4, nascMed);             // mes             // ano
                    stmt.setString(7, telefoneMed);     // telefone
                    stmt.setString(8, enderecoMed);     // endereco
                    stmt.setString(9, crmMed);          // crm
                    stmt.setString(10, especialidadeMed);// especialidade
                    stmt.setInt(11, SenhaMed);
                    stmt.executeUpdate(sql);
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    public void delete(int iddeletado) {
        String sql = "delete from usuário where id = ?";
        try (Connection conn = ConexaoDB.getConexao(); PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, iddeletado);
            int rowAffected = stmt.executeUpdate();
            System.out.println(rowAffected + " linhsa deletados.");
        } catch (SQLException e) {
            e.printStackTrace();

        }
    }

    public void update(String nome, int idupdate) throws SQLException {
        String sqlUpdate = "UPDATE usuario SET nome = ? WHERE id = ?";
        try (
                Connection conn = ConexaoDB.getConexao(); PreparedStatement pstmtUpdate = conn.prepareStatement(sqlUpdate)) {
            pstmtUpdate.setString(1, nome);
            pstmtUpdate.setInt(1, idupdate);//id do resgistro a ser atualizado
            int rowsAffected = pstmtUpdate.executeUpdate();
            System.out.println(rowsAffected + " linhas atualizadas");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

//metodos para dlete e update seguem a logica similar ao insert
}
