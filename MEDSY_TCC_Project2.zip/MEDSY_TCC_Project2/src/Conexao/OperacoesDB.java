package Conexao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import Telas.Cads.TelaCadMed;

public class OperacoesDB {

    public void Select() {
        String sql = "SELECT * FROM usuario";
        try (
                //estabeleça a coneção do banco de dados
                Connection conn = ConexaoDB.getConexao(); //prepara os o comando sql a ser executado
                 PreparedStatement stmt = conn.prepareStatement(sql); //rs recebe a execução da query
                 ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                //processa resultados 
                String nomef = rs.getString("nome");
                String email = rs.getString("email");

                System.out.println("deu boa " + nomef + " o email é: " + email);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public class Medico {

        private String nomem;
        private float CpfM;
        private String emailm;
        private String nascm;
        private String telefonem;
        private String enderecom;
        private String crm;
        private String especialidadem;
        private int SenhaM;

        public Medico(String nomem, float CpfM, String emailm, String nascm, String telefonem, String enderecom, String crm, String especialidadem ,int SenhaM) {
            this.nomem = nomem;
            this.CpfM = CpfM;
            this.emailm = emailm;
            this.nascm = nascm;
            this.telefonem = telefonem;
            this.enderecom = enderecom;
            this.crm = crm;
            this.especialidadem = especialidadem;
            this.SenhaM = SenhaM;
        }

        

        public void INSERTMEDICO(String nomem, float CpfM, String emailm, String nascm, String telefonem, String enderecom, String crm, String especialidadem, int SenhaM) {

            String sql = "INSERT INTO MEDICO (NOME, CPFM, EMAIL, NASCM,TELEFONEM, ENDERECOM, CRM, ESPECIALIDADE, SENHAM) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
            try (Connection conn = ConexaoDB.getConexao(); PreparedStatement stmt = conn.prepareStatement(sql); ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    stmt.setString(1, nomem);         // nome
                    stmt.setFloat(2, CpfM);           // cpf
                    stmt.setString(3, emailm);        // email
                    stmt.setString(4, nascm);             // mes             // ano
                    stmt.setString(7, telefonem);     // telefone
                    stmt.setString(8, enderecom);     // endereco
                    stmt.setString(9, crm);          // crm
                    stmt.setString(10, especialidadem);// especialidade
                    stmt.setInt(11, SenhaM);
                    stmt.executeUpdate(sql);
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    public void delete(int iddeletado) {
        String sql = "delete from usuário where id = ?";
        try (Connection conn = ConexaoDB.getConexao(); PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, iddeletado);
            int rowAffected = stmt.executeUpdate();
            System.out.println(rowAffected + " linhsa deletados.");
        } catch (SQLException e) {
            e.printStackTrace();

        }
    }

    public void update(String nome, int idupdate) throws SQLException {
        String sqlUpdate = "UPDATE usuario SET nome = ? WHERE id = ?";
        try (
            Connection conn = ConexaoDB.getConexao(); PreparedStatement pstmtUpdate = conn.prepareStatement(sqlUpdate)) {
            pstmtUpdate.setString(1, nome);
            pstmtUpdate.setInt(1, idupdate);//id do resgistro a ser atualizado
            int rowsAffected = pstmtUpdate.executeUpdate();
            System.out.println(rowsAffected + " linhas atualizadas");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

//metodos para dlete e update seguem a logica similar ao insert
}
